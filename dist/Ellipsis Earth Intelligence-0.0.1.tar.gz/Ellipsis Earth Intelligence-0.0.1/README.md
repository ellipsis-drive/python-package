This package is meant to help you interact with the Ellipsis API.

For documentation and examples see ellipsis-earth.com.
