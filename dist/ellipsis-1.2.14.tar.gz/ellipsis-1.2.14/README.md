This package is meant to help you interact with the Ellipsis API.

For documentation see https://app.ellipsis-drive.com/developer/python/documentation.

