This package is meant to help you interact with the Ellipsis API.

You can install this package using 

``
pip install ellipsis
``

For documentation see https://app.ellipsis-drive.com/developer/python/documentation.

