This package is meant to help you interact with the Ellipsis API.

For documentation see ellipsis-earth.com/products/pythonDocumentation.
For a tutorial see ellipsis-earth.com/products/pythonTutorial.
For examples see ellipsis-earth.com/gallery

